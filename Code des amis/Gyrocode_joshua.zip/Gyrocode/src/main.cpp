#include <Arduino.h>

// IHM
#include <WiFi.h>
#include <esp_now.h>
#include "rgb_lcd.h"
#include "FastLED.h"
#include <String.h>
#include <PS4Controller.h>
#include "esp_bt_main.h"
#include "esp_bt_device.h"
#include "esp_gap_bt_api.h"
#include "esp_err.h"

// Mesures et calculs
#include "Encodeur.h"
#include <Wire.h>
#include "Adafruit_MPU6050.h"
#include <Adafruit_Sensor.h>
#include <math.h>

// Ne pas utiliser la bibliothèque "Gyropode", elle n'est pas encore fonctionnelle, de toutes façons elle n'est pas compilée car non présente dans platformio.ini

// adresse MAC de la manette
// C8:F0:9E:2C:07:B2

// objets pour MPU 6050, détermination de la position angulaire
Adafruit_MPU6050 mpu;       // création de l'objet du MPU6050
sensors_event_t a, g, temp; // pour récupérer les données de l'accéléromètre et du gyroscope

// Encodeurs
Encodeur encodeurDroit(19, 18);
Encodeur encodeurGauche(36, 4);

// objets pour l'IHM
rgb_lcd lcd; // écran LCD

char flagCalcul = 0;
float te = 10; // période d'échantillonage en ms

// variables pour l'asservissement de la position Angulaire
float thetaOffset = -0.035; // angle auquel le gyropode semble stable


float consigneAngGyropode, consigneAngGyropodePrecedent; // consigne de position angulaire du gyropode
float erreurPosAng;         // erreur de la position angulaire
float arctan, arctanFiltre;
float omega, omegaTau, omegaFiltre;
float positionAngulaire;
float A, B;      // coefficients du filtre pour l'asservissement de la position angulaire
float tau = 100; // constante de temps du filtre en ms

float kp = 450; // kp pour la stabilisation la position angulaire
float kd = 40;  // kd pour la stabilisation la position angulaire
float ki = 0.0; // ki pour la stabilisation la position angulaire

// Asservissement de vitesse
float tauVit = 333;    // temps de réponse du filtre passe bas appliqué à la dérivée de la valeur moyenne des encodeurs
float tauLStickX = 10; // temps de réponse du filtre passe bas appliqué à la consigne de rotation du gyropode

float consigneVitGyropode; // consigne de vitesse du gyropode

float erreurVit, erreurVitPrecedente, erreurVitSum; // erreur de vitesse
float vitesseRotation;                              // vitesse de rotation du moteur non filtrée
float vitesseRotationFiltre;                        // vitesse de rotation du moteur filtrée

float kpVitesse = -0.130; // kp pour la stabilisation de la position (translation)
float kdVitesse = -30;    // kd pour la stabilisation de la position (translation)
float kiVitesse = 0.0;    // ki pour la stabilisation de la position (translation)

float corrIVit;          // correction intégrale de la vitesse
float corrIVitMax = 0.0; // valeur maximale de la correction intégrale de la vitesse maximale (en appliquant la saturation numérique)

float AVit, BVit;         // coefficients du filtre pour l'asservissement de la vitesse
float ALStickX, BLStickX; // coefficients du filtre pour le contrôle de la rotation

// variables encodeurs
int positionGauche;
int positionDroite;
float positionRotation;
float positionRotationPrecedent;

// variables pour le contrôle des moteurs :
float commandeMot; // commande du moteur
float commandeMotDroit;
float commandeMotGauche;

// Variables PWM
int frequence = 20000; // fréquence de la PWM
int resolution = 8;    // résolution de la PWM

// Channels PWM, on peut en mettre moins non?
int pwmChannelA1 = 0;
int pwmChannelA2 = 1;
int pwmChannelB1 = 2;
int pwmChannelB2 = 3;

// Pins qui envoient les PWM
int pwmA1 = 32;
int pwmA2 = 33;

int pwmB1 = 25;
int pwmB2 = 26;

int compFsec = 35; // compensation des frottements secs

// Variables IHM
// boutons
int boutonG = 34; // pin du bouton gauche
int boutonD = 27; // pin du bouton droit
int boutonM = 35; // pin du bouton milieu

int valBG; // valeur du bouton gauche
int valBM; // valeur du bouton milieu
int valBD; // valeur du bouton droit

// LEDS
int ledV = 14;
int ledR = 13;
int ledJ = 12;

// Gestion d'alimentation
int vBat = 39;             // tension de la batterie, en entrée du système on a (7.2V-0.6)/2 = 3.3V soit une valeur de 4095 si la batterie est chargée à 7.2V
int transistorRelais = 23; // transistor qui contrôle le relais de l'automaintien

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// manette PS4
unsigned long lastTimeStamp = 0;
#define EVENTS 0
#define BUTTONS 1
#define JOYSTICKS 1
#define TRIGGERS 1
#define SENSORS 0
#define ARROW 1

void onConnect(); // fonction de callback quand la mannette se connecte

void onDisConnect(); // fonction de callback quand la mannette se déconnecte

void notify(); // fonction de callback quand l'on reçoit une donnée via la mannette

void removePairedDevices(); // enlève les appareils déjà connectés

void printDeviceAddress(); // affiche l'adresse MAC de l'appareil

// boutons de du côté droit de la manette
int square;
int triangle;
int cross;
int circle;

// boutons du côté gauche de la manette
int up;    // sert à faire pencher le robot vers l'arrière en incrémentant positivement le thetaOffset
int down;  // sert à faire pencher le robot vers l'avant en incrémentant négativement le thetaOffset
int left;  // réinitialise la valeur de thetaOffset à une valeur où le robot est stable (dépend du bricolage qu'il y a dessus, sans bricolage il est stable)
int right; // sert à rien pour le moment

// joystick gauche (le droit n'est actuellement pas utilisé)
int LStickX, LStickXFiltre;
int LStickY;

// gachettes de la manette
int rightTrigger; // sert à faire avancer le robot
int leftTrigger;  // sert  à faire reculer le robot

// variables pour le filtre passe bas appliqué à la valeur des gachettes (sinon les valeurs sont trop bruitées)
// note : on peut mettre un tauTrigger plus grand pour modifier la vitesse de réponse du filtre et ainsi avoir une commande de vitesse filtrée semblable à une rampe
float ATrigger, BTrigger, tauTrigger = 500;
float consigneVitGyropodeFiltre; // consigne de vitesse filtrée du gyropode

// Mises A Echelle de la commande de vitesse : (ValeurCommandeMax*MAE) :
float MAEConsigneTriggerR = 0.0035; // valeur max : 255
float MAEConsigneTriggerL = 0.0035; // valeur max : 255
float MAEConsigneLStick = 0.492;    // valeur min : -127, valeur max : 127

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// LEDS adressables en dessous du gyropode :
// SK6812 : mes LEDs (en dessous du gyropode)
// WS2812B LEDs de Freddy (pas encore utilisées)

#define NUM_LEDS 10 // nombre de LEDS
#define DATA_PIN 27 // pin qui envoie les commandes de couleur

CRGB leds[NUM_LEDS];

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Servomoteur :

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

// IHM
void IHM_init(void);     // initialisation des outils de l'IHM
void readButtons(void);  // Lecture des boutons poussoirs
void reception(char ch); // Réception des commandes de l'IHM via l'UART USB
void checkvBat(void);    // vérification de la tension de la batterie
bool isBetween(float valeur, float borneMin, float borneMax)
{ // Vérifie si la valeur est comprise entre les bornes (pour les LEDS)
  // Vérifie si la valeur est comprise entre les bornes
  return (valeur >= fmin(borneMin, borneMax)) && (valeur <= fmax(borneMin, borneMax));
}

// Manette PS4
void removePairedDevices();
void printDeviceAddress();

// Contrôle des moteurs
void PWM_init(void);                   // initialisation des PWM des moteurs
int compensationFsecMot(int commande); // compensation des frottements secs
int saturationCommande(int commande);  // saturation numérique de la commande des moteurs

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

// Fonction qui effectue les calculs et les commandes des moteurs
void controleGyro(void *parameters)
{

  TickType_t xLastWakeTime;
  xLastWakeTime = xTaskGetTickCount();

  while (1)
  {

    mpu.getEvent(&a, &g, &temp); // récupération des données de l'accéléromètre et du gyroscope

    arctan = atan2(a.acceleration.y, a.acceleration.x); // récupération de la position angulaire BF
    arctanFiltre = A * arctan + B * arctanFiltre;       // filtre passe bas

    omega = -g.gyro.z;                            // récupération de la position angulaire HF
    omegaTau = omega * tau / 1000;                // omega*tau
    omegaFiltre = A * omegaTau + B * omegaFiltre; // filtre passe haut

    positionAngulaire = omegaFiltre + arctanFiltre; // filtre complémentaire

    ////////////////////////////////////////////////////////
    // modification de la consigne de vitesse du gyropode en fonction des valeurs renvoyées par la manette :

    if (triangle == 1)
    {
      kiVitesse += 0.0000001;
    }
    if (cross == 1)
    {
      kiVitesse -= 0.0000001;
    }

    if (leftTrigger < 30)
    {
      leftTrigger = 0;
    }

    if ((LStickX < 30) && (LStickX > 0))
    {
      LStickX = 0;
    }

    if (up == 1)
    {
      thetaOffset += 0.001;
    }

    if (down == 1)
    {
      thetaOffset -= 0.001;
    }

    if (left == 1)
    {
      thetaOffset = -0.035;
    }

    LStickX = LStickX * MAEConsigneLStick;
    LStickXFiltre = LStickX * ALStickX + BLStickX * LStickXFiltre;

    // filtrage de la commande
    consigneVitGyropode = rightTrigger * MAEConsigneTriggerR - leftTrigger * MAEConsigneTriggerL;
    consigneVitGyropodeFiltre = ATrigger * consigneVitGyropode + BTrigger * consigneVitGyropodeFiltre;

    ////////////////////////////////////////////////////////////////////////////////////////////
    // Asservissement de la vitesse du gyropode
    positionAngulaire = positionAngulaire - thetaOffset; // correction de l'offset causée par la position du MPU6050

    // mesures des valeurs des encodeurs
    positionGauche = encodeurGauche.getCount();
    positionDroite = encodeurDroit.getCount();

    positionRotationPrecedent = positionRotation;             // sauvegarde de la position moyenne précédente
    positionRotation = (positionGauche + positionDroite) / 2; // position moyenne des encodeurs

    vitesseRotation = (positionRotation - positionRotationPrecedent) / (te);       // vitesse de rotation moyenne des roues
    vitesseRotationFiltre = vitesseRotation * AVit + vitesseRotationFiltre * BVit; // filtre passe bas pour filtrer les bruits

    erreurVitPrecedente = erreurVit;                               // sauvegarde de l'erreur de vitesse précédente
    erreurVit = consigneVitGyropodeFiltre - vitesseRotationFiltre; // erreur de vitesse
    erreurVitSum += erreurVit;                                     // somme des erreurs de vitesse
    corrIVit = kiVitesse * erreurVitSum * te;                      // correction intégrale de la vitesse

    if (corrIVit >= corrIVitMax)
    {
      corrIVit = corrIVitMax;
    }
    if (corrIVit <= -corrIVitMax)
    {
      corrIVit = -corrIVitMax;
    }

    consigneAngGyropode = erreurVit * kpVitesse;                                                    // correction proportionnelle de la position angulaire du gyropode
    consigneAngGyropode = consigneAngGyropode + kdVitesse * (erreurVit - erreurVitPrecedente) / te; // correction dérivée
    consigneAngGyropode = consigneAngGyropode + corrIVit;                                           // correction intégrale

    //////////////////////////////////////////////////////////

    // Asservissement de la position angulaire+-

    erreurPosAng = consigneAngGyropode - positionAngulaire; // calcul de l'erreur  de position  angulaire

    commandeMot = erreurPosAng * kp;        // correction proportionnelle
    commandeMot = commandeMot - omega * kd; // correction dérivée
    // inutile de mettre une correction intégrale

    // assignation des commandes des moteurs droite et gauche
    commandeMotDroit = commandeMot;
    commandeMotGauche = commandeMot;

    // Contrôle de la rotation du gyropode
    if (LStickXFiltre > 0)
    {
      commandeMotDroit = commandeMotDroit - LStickXFiltre;
      commandeMotGauche = commandeMotGauche + LStickXFiltre;
    }
    if (LStickXFiltre < 0)
    {
      commandeMotDroit = commandeMotDroit - LStickXFiltre;
      commandeMotGauche = commandeMotGauche + LStickXFiltre;
    }

    // compensation des frottements secs
    commandeMotDroit = compensationFsecMot(commandeMotDroit);
    commandeMotGauche = compensationFsecMot(commandeMotGauche);

    // saturation numérique des commandes des moteurs
    commandeMotDroit = saturationCommande(commandeMotDroit);
    commandeMotGauche = saturationCommande(commandeMotGauche);

    // commande des moteurs
    ledcWrite(pwmChannelA1, 127 - commandeMotDroit);
    ledcWrite(pwmChannelA2, 127 + commandeMotDroit);

    ledcWrite(pwmChannelB1, 127 + commandeMotGauche);
    ledcWrite(pwmChannelB2, 127 - commandeMotGauche);

    flagCalcul = 1; // lève le flag de calcul
    vTaskDelayUntil(&xLastWakeTime, pdMS_TO_TICKS(te));
  }
}

void controleLED(void *parameters)
{

  TickType_t xLastWakeTime;
  xLastWakeTime = xTaskGetTickCount();

  int adjustedPosition;
  
  for (;;)
  {
    FastLED.setBrightness(255);

    if (positionAngulaire < -0.5 || positionAngulaire > 0.5)
    {
      // Si la position angulaire est en dehors de la plage acceptable, mettre les LED en rouge
      for (int i = 0; i < NUM_LEDS; i++)
      {
        leds[i] = CRGB(0,255, 0); // Rouge
      }
    }
    else
    {
      // Calculer les couleurs en fonction de la position angulaire entre -0.5 et 0.5
      float adjustedPosition = map(positionAngulaire, -0.5, 0.5, 0, 1); // Ajustement de la plage de -0.5:0.5 à 0:1
      for (int i = 0; i < NUM_LEDS; i++)
      {
        leds[i] = CRGB(255 * (1 - adjustedPosition), 255 * adjustedPosition, 0); // GRB
      }
    }

    FastLED.show();

    vTaskDelayUntil(&xLastWakeTime, pdMS_TO_TICKS(100));
  }
}

void setup()
{
  Serial.begin(115200);

  IHM_init();                                             // initialisation des outils de l'IHM
  PWM_init();                                             // initialisation des sorties PWM pour les moteurs
  FastLED.addLeds<SK6812, DATA_PIN, RGB>(leds, NUM_LEDS); // couleurs GRB : Green Red Blue

  while (!mpu.begin())
  { // Si le MPU n'est pas détecté, on allume la LED rouge pour le signaler, et on bloque le programme

    leds[2] = CRGB::Green;
    leds[7] = CRGB::Green;
    FastLED.show();
    delay(300);
    leds[1] = CRGB::Green;
    leds[3] = CRGB::Green;
    leds[6] = CRGB::Green;
    leds[8] = CRGB::Green;
    FastLED.show();
    delay(300);
    leds[0] = CRGB::Green;
    leds[4] = CRGB::Green;
    leds[5] = CRGB::Green;
    leds[9] = CRGB::Green;
    FastLED.show();
    delay(300);
    // éteindre toutes les LEDs
    for (int i = 0; i < NUM_LEDS; i++)
    {
      leds[i] = CRGB::Black;
    }
    FastLED.show();
    delay(300);
  }

  for (int i = 0; i <= NUM_LEDS; i++)
  { // éteindre toutes les LEDs
    leds[i] = CRGB::Black;
  }
  FastLED.show();

  // Réinitialisation de la valeur des encodeurs
  encodeurDroit.clearCount();
  encodeurGauche.clearCount();

  mpu.setGyroRange(MPU6050_RANGE_2000_DEG); // Augementation de la vitesse de mesure du capteur

  xTaskCreate(
      controleGyro,   // nom de la fonction
      "controleGyro", // nom de la tache que nous venons de créer
      10000,          // taille de la pile en octet
      NULL,           // parametre
      5,              // tres haut niveau de priorite
      NULL            // descripteur
  );

  // xTaskCreate(
  //     controleLED,   // nom de la fonction
  //     "controleLED", // nom de la tache que nous venons de créer
  //     10000,         // taille de la pile en octet
  //     NULL,          // parametre
  //     20,            // haut niveau de priorite
  //     NULL           // descripteur
  // );

  // calcul coeff filtres :

  // filtre pour l'asservissement de la position angulaire
  A = 1 / (1 + tau / te);
  B = tau / te * A;

  // filtre pour l'asservissement de la vitesse
  AVit = 1 / (1 + tauVit / te);
  BVit = tauVit / te * AVit;

  // filtre de la consigne de vitesse
  ATrigger = 1 / (1 + tauTrigger / te);
  BTrigger = tauTrigger / te * ATrigger;

  // filtre de la consigne de rotation
  ALStickX = 1 / (1 + tauLStickX / te);
  BLStickX = tauLStickX / te * ALStickX;

  // Connexion à la manette PS4 et affectation des fonctions de callback
  PS4.attach(notify);
  PS4.attachOnConnect(onConnect);
  PS4.attachOnDisconnect(onDisConnect);
  PS4.begin("C8:F0:9E:2C:07:B2");
  removePairedDevices(); // This helps to solve connection issues
  // Serial.print("This device MAC is: ");
  // printDeviceAddress();
  // Serial.println("");
  PS4.setLed(1, 255, 1); // marche pas?
}

void loop()

{

  if (flagCalcul == 1) // Si on a fait un calcul
  {

    // Serial.printf("%d %5.2lf %5.2lf %5.2lf\n", commandeMot, consigneAngGyropode, vitesseRotation); // erreur Vit
    Serial.printf("%lf %lf \n", vitesseRotation, vitesseRotationFiltre);

    flagCalcul = 0; // on baisse le flag
  }
}

void serialEvent()
{ // S'il se passe quelque chose sur la liaison série

  while (Serial.available() > 0) // tant qu'il y a des caractères à lire
  {
    reception(Serial.read());
  }
}

void reception(char ch)
{ // récéption et traitement des commandes reçues par l'UART USB

  static int i = 0;
  static String chaine = "";
  String commande;
  String valeur;
  int index, length;

  if ((ch == 13) or (ch == 10))
  {
    index = chaine.indexOf(' ');
    length = chaine.length();
    if (index == -1)
    {
      commande = chaine;
      valeur = "";
    }
    else
    {
      commande = chaine.substring(0, index);
      valeur = chaine.substring(index + 1, length);
    }

    if (commande == "Tau")
    {
      tau = valeur.toInt();
      // calcul coeff filtre
      A = 1 / (1 + tau / te);
      B = tau / te * A;
    }
    if (commande == "Te")
    {
      te = valeur.toInt();
      A = 1 / (1 + tau / te);
      B = tau / te * A;
    }

    if (commande == "P")
    {
      kp = valeur.toFloat();
    }

    if (commande == "D")
    {
      kd = valeur.toFloat();
    }

    if (commande == "tauVit")
    {
      tauVit = valeur.toFloat();
      AVit = 1 / (1 + tauVit / te);
      BVit = tauVit / te * A;
    }
    if (commande == "tauLStickX")
    {
      tauLStickX = commande.toFloat();
      ALStickX = 1 / (1 + tauLStickX / te);
      BLStickX = tauLStickX / te * ALStickX;
    }
    if (commande == "PP")
    {
      kpVitesse = valeur.toFloat();
    }
    if (commande == "DD")
    {
      kdVitesse = valeur.toFloat();
    }
    if (commande == "KIP")
    {
      kiVitesse = valeur.toFloat();
    }

    if (commande == "FS")
    {
      compFsec = valeur.toFloat();
    }
    if (commande == "C")
    {
      thetaOffset = valeur.toFloat();
    }

    if (commande == "CVG")
    {
      consigneVitGyropode = valeur.toFloat();
    }
    if (commande == "TT")
    {
      tauTrigger = valeur.toFloat();
      ATrigger = 1 / (1 + tauTrigger / te);
      BTrigger = tauTrigger / te * ATrigger;
    }
    if (commande == "MAETL")
    {
      MAEConsigneTriggerL = valeur.toFloat();
    }
    if (commande == "MAETR")
    {
      MAEConsigneTriggerR = valeur.toFloat();
    }
    if (commande == "MAELS")
    {
      MAEConsigneLStick = valeur.toFloat();
    }

    if (commande == "CORRIVITMAX")
    {
      corrIVitMax = valeur.toFloat();
    }

    chaine = "";
  }

  else
  {
    chaine += ch;
  }
}

void IHM_init(void)
{

  pinMode(vBat, INPUT);
  pinMode(boutonD, INPUT_PULLDOWN);
  pinMode(boutonG, INPUT_PULLDOWN);
  pinMode(boutonM, INPUT_PULLDOWN);
  pinMode(ledJ, OUTPUT);
  pinMode(ledV, OUTPUT);
  pinMode(ledR, OUTPUT);
  printf("inputs et outputs initialisés");
}

void readButtons(void) // lecture des boutons poussoirs
{

  valBD = digitalRead(boutonD);
  valBM = digitalRead(boutonM);
  valBG = digitalRead(boutonG);
}

void checkvBat(void)
{
  if (analogRead(vBat) < 3000)
  {
    digitalWrite(transistorRelais, LOW);
  }
  else
  {
    digitalWrite(transistorRelais, HIGH);
  }
}

void PWM_init(void) // initialisation des PWM

{
  ledcSetup(pwmChannelA1, frequence, resolution);
  ledcSetup(pwmChannelA2, frequence, resolution);
  ledcSetup(pwmChannelB1, frequence, resolution);
  ledcSetup(pwmChannelB2, frequence, resolution);

  ledcAttachPin(pwmA1, pwmChannelA1);
  ledcAttachPin(pwmA2, pwmChannelA2);
  ledcAttachPin(pwmB1, pwmChannelB1);
  ledcAttachPin(pwmB2, pwmChannelB2);

  // initialisation du servomoteur
  // servo.attach(23);
  // servo.setPeriodHertz(400);
}

int compensationFsecMot(int commande)
{
  if (commande >= 0)
    commande = commande + compFsec;
  if (commande <= 0)
    commande = commande - compFsec;
  return commande;
}

int saturationCommande(int commande)
{
  if (commande >= 120)
  {
    commande = 120;
  }
  if (commande <= -120)
  {
    commande = -120;
  }

  return commande;
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// manette PS4

void removePairedDevices()
{
  uint8_t pairedDeviceBtAddr[20][6];
  int count = esp_bt_gap_get_bond_device_num();
  esp_bt_gap_get_bond_device_list(&count, pairedDeviceBtAddr);
  for (int i = 0; i < count; i++)
  {
    esp_bt_gap_remove_bond_device(pairedDeviceBtAddr[i]);
  }
}

void printDeviceAddress()
{
  const uint8_t *point = esp_bt_dev_get_address();
  for (int i = 0; i < 6; i++)
  {
    char str[3];
    sprintf(str, "%02x", (int)point[i]);
    Serial.print(str);
    if (i < 5)
    {
      Serial.print(":");
    }
  }
}

void onConnect()
{
  Serial.println("Connected!");
}

void onDisConnect()
{
  Serial.println("Disconnected!");
}

void notify()
{

#if EVENTS
  boolean sqd = PS4.event.button_down.square,
          squ = PS4.event.button_up.square,
          trd = PS4.event.button_down.triangle,
          tru = PS4.event.button_up.triangle;

#endif

#if BUTTONS
  boolean sq = PS4.Square(),
          tr = PS4.Triangle(),
          cr = PS4.Cross(),
          ci = PS4.Circle();

  // récupération des valeurs des boutons
  square = sq;
  triangle = tr;
  cross = cr;
  circle = ci;

#endif

  // Only needed to print the message properly on serial monitor. Else we dont need it.
  if (millis() - lastTimeStamp > 50)
  {

#if JOYSTICKS

    LStickX = PS4.LStickX();
    LStickY = PS4.LStickY();

#endif

#if SENSORS
    Serial.printf("gx:%5d,gy:%5d,gz:%5d,ax:%5d,ay:%5d,az:%5d\n",
                  PS4.GyrX(),
                  PS4.GyrY(),
                  PS4.GyrZ(),
                  PS4.AccX(),
                  PS4.AccY(),
                  PS4.AccZ());

#endif
    lastTimeStamp = millis();

#if TRIGGERS

    rightTrigger = PS4.R2Value();
    leftTrigger = PS4.L2Value();

#endif

#if ARROW

    up = PS4.Up();
    down = PS4.Down();
    left = PS4.Left();

#endif
  }
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////