#include "ENCODEUR.h"
#include <Arduino.h>
#include "ESP32Encoder.h"

Encodeur::Encodeur(int pinA, int pinB){
  encoder = new ESP32Encoder;
    // Config encodeur
    encoder->attachHalfQuad(pinA, pinB);
    encoder->clearCount();
    encoder->setCount(0);
}

void Encodeur::setCount(int count){
    encoder->setCount(count);
}
int Encodeur::getCount(){
    return encoder->getCount();
}
void Encodeur::clearCount(){
    encoder->clearCount();
}
