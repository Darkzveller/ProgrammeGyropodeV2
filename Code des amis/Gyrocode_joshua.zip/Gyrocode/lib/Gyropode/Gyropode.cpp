#include "Gyropode.h"
#include <Arduino.h>

void controleGyro(void *parameters){

}


Gyropode::Gyropode(uint32_t frequency, // fréquence de la PWM
             uint8_t resolution, // résolution de la PWM

             uint8_t channelA1,  // channel de la PWM du moteur 1
             uint8_t channelB1,  // channel de la PWM du moteur 2
             int pinPwmA1,       // pin de la PWM du moteur 1
             int pinPwmB1,       // pin de la PWM du moteur 2
             int pinEncodeurA1,  // pin A de l'encodeur du moteur 1
             int pinEncodeurB1,  // pin B de l'encodeur du moteur 1

             uint8_t channelA2,  // channel de la PWM du moteur 2
             uint8_t channelB2,  // channel de la PWM du moteur 2
             int pinPwmA2,       // pin de la PWM du moteur 2
             int pinPwmB2,       // pin de la PWM du moteur 2
             int pinEncodeurA2,  // pin A de l'encodeur du moteur 2
             int pinEncodeurB2)
{

    m_mpu = new Adafruit_MPU6050;                // on crée un nouvel objet de type MPU6050
    m_mpu->setGyroRange(MPU6050_RANGE_2000_DEG); // Augementation de la vitesse de mesure du capteur

    // Créer la tache RTOS pour le contrôle des moteurs
    xTaskCreate(
        controleGyro,   // nom de la fonction
        "controleGyro", // nom de la tache que nous venons de créer
        10000,          // taille de la pile en octet
        NULL,           // parametre
        10,             // tres haut niveau de priorite
        NULL            // descripteur
    );
}
