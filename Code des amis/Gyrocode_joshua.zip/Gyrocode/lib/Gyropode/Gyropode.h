#ifndef _GYROPODE_H
#define _GYROPODE_H

#include <Arduino.h>
#include <String.h>
#include <Wire.h>
#include "Adafruit_MPU6050.h"
#include <Adafruit_Sensor.h>
#include <math.h>
#include "rgb_lcd.h"
#include "Encodeur.h"

void controleGyro(void *parameters);

class Gyropode
{
public:
    Gyropode(uint32_t frequency, // fréquence de la PWM
             uint8_t resolution, // résolution de la PWM

             uint8_t channelA1,  // channel de la PWM du moteur 1
             uint8_t channelB1,  // channel de la PWM du moteur 2
             int pinPwmA1,       // pin de la PWM du moteur 1
             int pinPwmB1,       // pin de la PWM du moteur 2
             int pinEncodeurA1,  // pin A de l'encodeur du moteur 1
             int pinEncodeurB1,  // pin B de l'encodeur du moteur 1

             uint8_t channelA2,  // channel de la PWM du moteur 2
             uint8_t channelB2,  // channel de la PWM du moteur 2
             int pinPwmA2,       // pin de la PWM du moteur 2
             int pinPwmB2,       // pin de la PWM du moteur 2
             int pinEncodeurA2,  // pin A de l'encodeur du moteur 2
             int pinEncodeurB2); // pin B de l'encodeur du moteur 2



    char flagCalcul = 0;
    float te = 10; // période d'échantillonage en ms

    // variables pour l'asservissement de la position Angulaire
    float thetaOffset = -0.035; // angle auquel le gyropode semble stable
    float erreurPosAng;         // erreur de la position angulaire

    float consigneAngGyropode, consigneAngGyropodePrecedent; // consigne de position angulaire du gyropode
    float arctan, arctanFiltre;
    float omega, omegaTau, omegaFiltre;
    float positionAngulaire, positionAngulairePrecedent;
    float A, B;      // coefficients du filtre pour l'asservissement de la position angulaire
    float tau = 100; // constante de temps du filtre en ms

    float kp = 450; // kp pour la stabilisation la position angulaire
    float kd = 40;  // kd pour la stabilisation la position angulaire
    float ki = 0.0; // ki pour la stabilisation la position angulaire

    // Asservissement de la vitesse
    float tauVit = 333;        // temps de réponse du filtre passe bas appliqué à la dérivée de la valeur moyenne des encodeurs
    float consigneVitGyropode; // consigne de vitesse du gyropode

    float erreurVit, erreurVitPrecedente, erreurVitSum; // erreur de vitesse
    float vitesseRotation;                              // vitesse de rotation du moteur non filtrée
    float vitesseRotationFiltre;                        // vitesse de rotation du moteur filtrée
    float kpVitesse = -0.130;                           // kp pour la stabilisation de la position (translation)
    float kdVitesse = -30;                              // kd pour la stabilisation de la position (translation)
    float kiVitesse = 0.0;                              // ki pour la stabilisation de la position (translation)

    float AVit, BVit; // coefficients du filtre pour l'asservissement de la vitesse :

    // variables encodeurs
    int positionGauche;
    int positionDroite;
    float positionRotation;
    float positionRotationPrecedent;

    // variables pour le contrôle des moteurs :
    float commandeMot; // commande du moteur
    float commandeMotDroit;
    float commandeMotGauche;

    // Variables PWM
    int frequence = 20000; // fréquence de la PWM
    int resolution = 8;    // résolution de la PWM

    // Channels PWM, on peut en mettre moins non?
    int pwmChannelA1 = 0;
    int pwmChannelA2 = 1;
    int pwmChannelB1 = 2;
    int pwmChannelB2 = 3;

    // Pins qui envoient les PWM
    int pwmA1 = 32;
    int pwmA2 = 33;

    int pwmB1 = 25;
    int pwmB2 = 26;

    int compFsec = 35; // compensation des frottements secs

private:
    Adafruit_MPU6050 *m_mpu; // création de l'objet du MPU6050
};









//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
class IHM
{
public:
    IHM(String bluetoothName);
    void setScreenColor(int red, int green, int blue);
    void buttons(bool enable);
    void readButtons(int &valBG, int &valBM, int &valBD);
    void setLed(int led, bool state);
    void checkVbat(void);                       // gestion de la batterie
    void receptionBluetooth(char charReceived); // permet de recevoir et traiter les commandes bluetooth

private:
    // Variables IHM
    // boutons
    int boutonG = 34; // pin du bouton gauche
    int boutonD = 27; // pin du bouton droit
    int boutonM = 35; // pin du bouton milieu

    int valBG; // valeur du bouton gauche
    int valBM; // valeur du bouton milieu
    int valBD; // valeur du bouton droit

    // LEDS
    int ledV = 14;
    int ledR = 13;
    int ledJ = 12;

    // Gestion d'alimentation
    int vBat = 39;             // tension de la batterie, en entrée du système on a (7.2V-0.6)/2 = 3.3V soit une valeur de 4095 si la batterie est chargée à 7.2V
    int transistorRelais = 23; // transistor qui contrôle le relais de l'automaintien
};

#endif